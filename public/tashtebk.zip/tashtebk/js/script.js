$(document).ready(function(){
    var heightHeader = $("header").innerHeight() 
    var heightFooter = $("footer").innerHeight() 
    var result = heightHeader + heightFooter

    $("main").css({'min-height': 'calc(100vh - '+ heightFooter + 'px )' , 'padding-top' : heightHeader +'px'})
    $(".main1").css({ 'padding-top' : '0'})
   
     $(".xzoom, .xzoom-gallery").xzoom();
        //Integration with FancyBox 2 plugin
        $('.xzoom:first').bind('click', function() {
            var xzoom = $(this).data('xzoom');
            xzoom.closezoom();
            $.fancybox.open(xzoom.gallery().cgallery, {padding: 0, helpers: {overlay: {locked: false}}});
            event.preventDefault();
        });
 
  $('ul.drop li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
}); 

 $(".mobile .menu-toggle").click(function() {
	$(this).parent().next(".mobile-nav").toggle(0 , "display");
});
  

  new WOW().init();

	$('header nav li a').click(function(){
	$('html , body').animate({
    scrollTop : $('#' + $(this).data('value')).offset().top},1400);
    });


    $( function() {
      $( "#slider" ).slider();
    } );

    var swiper = new Swiper('.swiper-product', {
      slidesPerView: 4,
      spaceBetween: 30,
      // init: false,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        1024: {
          slidesPerView: 4,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        }
      }
      
      
      
    });
     var swiper = new Swiper('.swiper-related', {
      slidesPerView: 4,
      spaceBetween: 40,
    //   slidesPerGroup: 3,
      // init: false,
    //   autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    //   },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        1024: {
          slidesPerView: 4,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        }
      }
      
      
      
    });
     var swiper = new Swiper('.swiper-multirows', {
          slidesPerView: 4,
          slidesPerColumn: 1,
          spaceBetween: 30,
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
        });

    var swiper = new Swiper('.swiper-ctg', {
      slidesPerView: 4,
      spaceBetween: 30,
      // init: false,
      /*autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },*/
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        1024: {
          slidesPerView: 4,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 30,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        }
      }
      
      
      
    });

    $('.add').click(function () {
      if ($(this).prev().val() < 100) {
        $(this).prev().val(+$(this).prev().val() + 1);
      }
  });
  $('.sub').click(function () {
      if ($(this).next().val() > 1) {
        if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
      }
  });
  });
  
    var swiper = new Swiper('.swiper-gallary', {
      slidesPerView: 3,
      spaceBetween: 20,
       pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
     
    });
    
    
    function zoom(e){
  var zoomer = e.currentTarget;
  e.offsetX ? offsetX = e.offsetX : offsetX = e.touches[0].pageX
  e.offsetY ? offsetY = e.offsetY : offsetX = e.touches[0].pageX
  x = offsetX/zoomer.offsetWidth*100
  y = offsetY/zoomer.offsetHeight*100
  zoomer.style.backgroundPosition = x + '% ' + y + '%';
}